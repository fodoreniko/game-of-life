# javafx-game-starter-jdk17

Basic JavaFX starter project that draws graphics on a canvas, based on JDK 17.

Run the application with `./gradlew run`.
