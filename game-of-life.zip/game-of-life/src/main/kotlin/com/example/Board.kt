package com.example


class Board(val length: Int, val width: Int) {
    var array = Array(length) { IntArray(width) }
    var nextState = Array(length) { IntArray(width) }

    fun create() {
        for(i in 0 until length) {
            for (j in 0 until width) {
                array[i][j] = 0
            }
        }
    }

    private fun checkIndexX(x: Int): Boolean {
        return ((x >= 0) && (x < length))
    }

    private fun checkIndexY(x: Int): Boolean {
        return ((x >= 0) && (x < width))
    }

    fun countNeighbours() {
        for (x in 0 until length) {
            for (y in 0 until width) {
                var count = 0

                for (i in x - 1..x + 1) {
                    for (j in y - 1..y + 1) {
                        if (checkIndexX(i) && checkIndexY(j) && array[i][j] == 1) {
                            count++
                            }
                        }
                    }
                if(array[x][y] == 1) count--
                nextState[x][y] = when {
                    (array[x][y] == 1 && count in 2..3) -> 1
                    (array[x][y] == 0 && count == 3) -> 1
                    else -> 0
                }
            }
        }
        for (ver in 0 until length) {
            for (hor in 0 until width) {
                array[ver][hor] = nextState[ver][hor]
            }
        }
    }

}