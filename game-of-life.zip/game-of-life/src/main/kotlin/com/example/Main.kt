package com.example
import tornadofx.*

import javafx.application.Application

fun main(args: Array<String>) {
    Application.launch(Game::class.java, *args)
}
